package com.ongames.services;

import com.ongames.model.Categoria;
import com.ongames.model.repository.CategoriaRepository;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class CategoriaService {
    public CategoriaRepository repo;
    
    public Categoria save(Categoria cat){
        verificaCategoriaSeCadastrada(cat);
        try{
            return repo.save(cat);
        }
        catch (Exception e){
            throw new RuntimeException("Erro ao cadastrar/atualizar categoria");
        }        
    }
    
     public Categoria update(Categoria cat){
        Categoria cDB = repo.getById(cat.getId());
        if (cDB == null){
            throw new RuntimeException("Não é possível atualizar uma categoria não cadastrada");
        }
        try{
            return repo.save(cat);
        }
        catch (Exception e){
            throw new RuntimeException("Erro ao cadastrar/atualizar categoria");
        }        
    }
    
    public void delete(Categoria cat){
        try{
            repo.delete(cat);
        }
        catch (Exception e){
            throw new RuntimeException ("Erro ao excluir categoria");
        }
    }  
    
    private void verificaCategoriaSeCadastrada(Categoria cat){
        List<Categoria> resultado = repo.findByTipo(cat.getTipo());
        if (!resultado.isEmpty()){
            throw new RuntimeException("Categoria já cadastrada");
        }
    }
}


